function initProductSlider() {
    const sliderThumbs = new Swiper('.slider__thumbs .swiper-container', {

        direction: 'vertical',
        slidesPerView: 4,
        spaceBetween: 24,
        navigation: {
            nextEl: '.slider__next',
            prevEl: '.slider__prev'
        },
        freeMode: true,
        breakpoints: {
            0: {
                direction: 'horizontal',
            },
            768: {
                direction: 'vertical',
            }
        }
    });

    const section = "section.slider .slider__images";
    const sliderImages = new Swiper('.slider__images .swiper-container', {

        direction: 'horizontal',
        slidesPerView: 1,
        spaceBetween: 32,
        mousewheel: true,

        navigation: {
            nextEl: '.slider__next',
            prevEl: '.slider__prev'
        },
        on: {
            slideChange: function () {
                setTimeout(() => {
                    let activeIndex = jQuery(section + ' .swiper-slide-active').attr('data-swiper-slide-index') - 1 + 1;
                    activeIndex = Math.ceil((activeIndex + 1)) < 10 ? "0" + Math.ceil((activeIndex + 1)) : +Math.ceil((activeIndex + 1));

                    let slides = jQuery(section + ' .swiper-slide:not(.swiper-slide-duplicate)').length;
                    slides = Math.ceil((slides)) < 10 ? "0" + Math.ceil((slides)) : +Math.ceil((slides));
                    document.querySelector(section + ' .slider__fraction').innerHTML = activeIndex + '/' + slides;
                }, 300);
            },
            resize: function () {
                setTimeout(() => {
                    let activeIndex = jQuery(section + ' .swiper-slide-active').attr('data-swiper-slide-index') - 1 + 1;
                    activeIndex = Math.ceil((activeIndex + 1)) < 10 ? "0" + Math.ceil((activeIndex + 1)) : +Math.ceil((activeIndex + 1));

                    let slides = jQuery(section + ' .swiper-slide:not(.swiper-slide-duplicate)').length;
                    slides = Math.ceil((slides)) < 10 ? "0" + Math.ceil((slides)) : +Math.ceil((slides));
                    document.querySelector(section + ' .slider__fraction').innerHTML = activeIndex + '/' + slides;
                }, 300);
            }


        },
        grabCursor: true,
        thumbs: {
            swiper: sliderThumbs
        },
        breakpoints: {
            0: {
                direction: 'horizontal',
            },
            768: {
                direction: 'horizontal',
            }
        }
    });
}