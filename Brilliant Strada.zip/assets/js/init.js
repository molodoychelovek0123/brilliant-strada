function initAll(){
    initProductSlider();
    jQuery('a').on('click', function (event){
        event.preventDefault();
        event.stopPropagation();
        let url = jQuery(this).attr('href');
        if( url !== "#" &&  url.length > 1)
            changePageTo(parseLink(url));
    });
}

document.addEventListener("DOMContentLoaded", function(event) {
    initScreen();
    initAll();
})